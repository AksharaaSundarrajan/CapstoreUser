package com.capgemini.store.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import com.capgemini.store.beans.Customer;
import com.capgemini.store.beans.Orders;
import com.capgemini.store.exceptions.CustomerNotFoundException;
import com.capgemini.store.exceptions.InvalidInputException;
import com.capgemini.store.exceptions.ProductUnavailableException;
import com.capgemini.store.services.CapStoreCustomerService;
import com.capgemini.store.services.CapStoreCustomerServiceImpl;
import com.capgemini.store.services.CapstoreServices;
import com.capgemini.store.services.CapstoreServicesImpl;

public class CapstoreTest {
	CapstoreServices capService;
	@Before
	public void initData(){
		Orders order = new Orders(1, products, userId, 1000, "Shipped", "true", "COD", merchant, elligibleReturnDate, orderPlacedOn, refundRequest, refundRequestDate)
		 Customer cust = new Customer("9884014909", address, "Aksharaa", "aku@gmail.com", "aku123", "123456789", "Heloo", "World", reviews, orders);
		capService = new CapstoreServicesImpl();
	}

	@Test(expected=NullPointerException.class)
	public void testSignUpFail1() {
		Customer customer = new Customer();
		capService.signUp(customer);
	}
	@Test
	public void testSignUpPass() {
		// add all valid values via constructor
		Customer customer = new Customer();
		capService.signUp(customer);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testForgotPasswordFail1() throws CustomerNotFoundException, InvalidInputException {
		capService.forgotPassword("9880987654");
	}
	@Test(expected=InvalidInputException.class)
	public void testForgotPasswordFail2() throws InvalidInputException, CustomerNotFoundException {
		capService.forgotPassword("987");
	}
	@Test
	public void testForgotPasswordPass() throws InvalidInputException, CustomerNotFoundException {
		capService.forgotPassword("9889090909");
	}
	@Test
	public void testSecurityQuestion() {
		fail("Not yet implemented");
	}

	@Test(expected=InvalidInputException.class)
	public void testOnlinePaymentFail() throws InvalidInputException {
		capService.onlinePayment("1234");
	}
	@Test
	public void testOnlinePaymentPass() throws InvalidInputException {
		capService.onlinePayment("123456789011");
	}
	@Test(expected=ProductUnavailableException.class)
	public void testAddToCartProductQuantityNotAvailable() throws ProductUnavailableException {
		capService.addToCart(101, 100);
	}
	@Test(expected=ProductUnavailableException.class)
	public void testUpdateCartProductQuantityNotAvailable() throws ProductUnavailableException {
		capService.updateCart(101, 1, 100);
	}

	@Test
	public void testRemoveProductFromCart() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddAddress() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetAddress() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateQuantity() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsRefundRequestValid() {
		fail("Not yet implemented");
	}

	@Test
	public void testApplyDiscount() {
		fail("Not yet implemented");
	}

	@Test
	public void testDiscountIsValid() {
		fail("Not yet implemented");
	}

	@Test
	public void testApplyCoupon() {
		fail("Not yet implemented");
	}

	@Test
	public void testCouponIsValid() {
		fail("Not yet implemented");
	}

	@Test
	public void testObject() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetClass() {
		fail("Not yet implemented");
	}

	@Test
	public void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	public void testEquals() {
		fail("Not yet implemented");
	}

	@Test
	public void testClone() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	@Test
	public void testNotify() {
		fail("Not yet implemented");
	}

	@Test
	public void testNotifyAll() {
		fail("Not yet implemented");
	}

	@Test
	public void testWaitLong() {
		fail("Not yet implemented");
	}

	@Test
	public void testWaitLongInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testWait() {
		fail("Not yet implemented");
	}

	@Test
	public void testFinalize() {
		fail("Not yet implemented");
	}

}
